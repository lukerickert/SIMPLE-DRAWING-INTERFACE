# -*- coding: utf-8 -*-
"""STEP loading and part list."""
import os

from OCP.BRep import BRep_Builder
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp
from OCP.TopoDS import TopoDS_Compound

from .project import bounding_box, _static

_volume_props = _static(BRepGProp, "VolumeProperties")


class Part(object):
    def __init__(self, pid, name, shape):
        self.id = pid
        self.name = name
        self.shape = shape          # TopoDS_Shape
        bb = bounding_box(shape)
        self.bbox = bb
        props = GProp_GProps()
        _volume_props(shape, props)
        self.volume = props.Mass()  # mm^3

    def info(self):
        x0, y0, z0, x1, y1, z1 = self.bbox
        return {"id": self.id, "name": self.name,
                "size_mm": [round(x1 - x0, 3), round(y1 - y0, 3), round(z1 - z0, 3)],
                "volume_mm3": round(self.volume, 1)}


def load_step(path):
    """Read a STEP file. Returns a list of Part, one per solid, named from the STEP labels."""
    from build123d import import_step
    comp = import_step(path)
    stem = os.path.splitext(os.path.basename(path))[0]
    parts = []
    names = {}

    def add(name, shape):
        name = name or stem
        n = names.get(name, 0)
        names[name] = n + 1
        if n:
            name = "%s_%d" % (name, n + 1)
        parts.append(Part(len(parts), name, shape))

    def walk(obj, inherited):
        label = getattr(obj, "label", "") or inherited
        children = list(getattr(obj, "children", None) or [])
        if children:
            for ch in children:
                walk(ch, label)
            return
        solids = obj.solids() if hasattr(obj, "solids") else []
        if len(solids) == 1:
            add(label, solids[0].wrapped)
        else:
            for i, s in enumerate(solids):
                add("%s_%d" % (label, i + 1) if label else "", s.wrapped)

    walk(comp, "")
    if not parts:
        for s in comp.solids():
            add("", s.wrapped)
    return parts


def compound(shapes):
    if len(shapes) == 1:
        return shapes[0]
    b = BRep_Builder()
    c = TopoDS_Compound()
    b.MakeCompound(c)
    for s in shapes:
        b.Add(c, s)
    return c
