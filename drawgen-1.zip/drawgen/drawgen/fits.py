# -*- coding: utf-8 -*-
"""ISO 286-1/-2 limits for holes and shafts, nominal sizes up to 500 mm, IT5 to IT11."""
import re

# upper limits of the nominal size ranges (mm); a size belongs to the range (previous, limit]
RANGES = [3, 6, 10, 18, 30, 50, 80, 120, 180, 250, 315, 400, 500]

IT = {   # standard tolerance grades (um)
    4: [3, 4, 4, 5, 6, 7, 8, 10, 12, 14, 16, 18, 20],
    5: [4, 5, 6, 8, 9, 11, 13, 15, 18, 20, 23, 25, 27],
    6: [6, 8, 9, 11, 13, 16, 19, 22, 25, 29, 32, 36, 40],
    7: [10, 12, 15, 18, 21, 25, 30, 35, 40, 46, 52, 57, 63],
    8: [14, 18, 22, 27, 33, 39, 46, 54, 63, 72, 81, 89, 97],
    9: [25, 30, 36, 43, 52, 62, 74, 87, 100, 115, 130, 140, 155],
    10: [40, 48, 58, 70, 84, 100, 120, 140, 160, 185, 210, 230, 250],
    11: [60, 75, 90, 110, 130, 160, 190, 220, 250, 290, 320, 360, 400],
}

# shaft fundamental deviations (um): upper deviation es for d..h, lower deviation ei for k..p
SHAFT_ES = {
    "d": [-20, -30, -40, -50, -65, -80, -100, -120, -145, -170, -190, -210, -230],
    "e": [-14, -20, -25, -32, -40, -50, -60, -72, -85, -100, -110, -125, -135],
    "f": [-6, -10, -13, -16, -20, -25, -30, -36, -43, -50, -56, -62, -68],
    "g": [-2, -4, -5, -6, -7, -9, -10, -12, -14, -15, -17, -18, -20],
    "h": [0] * 13,
}
SHAFT_EI = {
    "k": [0, 1, 1, 1, 2, 2, 2, 3, 3, 4, 4, 4, 5],          # IT4 to IT7; 0 for other grades
    "m": [2, 4, 6, 7, 8, 9, 11, 13, 15, 17, 20, 21, 23],
    "n": [4, 8, 10, 12, 15, 17, 20, 23, 27, 31, 34, 37, 40],
    "p": [6, 12, 15, 18, 22, 26, 32, 37, 43, 50, 56, 62, 68],
}
# r and s use finer subdivisions above 50 mm: (upper limit of sub-range, ei)
SHAFT_EI_SUB = {
    "r": [(3, 10), (6, 15), (10, 19), (18, 23), (30, 28), (50, 34), (65, 41), (80, 43), (100, 51), (120, 54),
          (140, 63), (160, 65), (180, 68), (200, 77), (225, 80), (250, 84), (280, 94), (315, 98), (355, 108),
          (400, 114), (450, 126), (500, 132)],
    "s": [(3, 14), (6, 19), (10, 23), (18, 28), (30, 35), (50, 43), (65, 53), (80, 59), (100, 71), (120, 79),
          (140, 92), (160, 100), (180, 108), (200, 122), (225, 130), (250, 140), (280, 158), (315, 170),
          (355, 190), (400, 208), (450, 232), (500, 252)],
}

HOLE_CLASSES = ["D10", "E9", "F7", "F8", "G7", "H6", "H7", "H8", "H9", "H11", "JS7", "K7", "M7", "N7", "P7"]
SHAFT_CLASSES = ["d9", "e8", "f7", "g6", "h6", "h7", "h9", "h11", "js6", "k6", "m6", "n6", "p6", "r6", "s6"]


def _index(size):
    if size <= 0 or size > 500:
        raise ValueError("ISO 286 table range is 0 to 500 mm")
    for i, lim in enumerate(RANGES):
        if size <= lim:
            return i
    raise ValueError("size out of range")


def _sub(table, size):
    for lim, v in table:
        if size <= lim:
            return v
    raise ValueError("size out of range")


def _shaft(letter, grade, size):
    """(es, ei) in um for a shaft."""
    i = _index(size)
    it = IT[grade][i]
    if letter == "js":
        return it / 2.0, -it / 2.0
    if letter in SHAFT_ES:
        es = SHAFT_ES[letter][i]
        return es, es - it
    if letter == "k":
        ei = SHAFT_EI["k"][i] if 4 <= grade <= 7 else 0
    elif letter in SHAFT_EI:
        ei = SHAFT_EI[letter][i]
    elif letter in SHAFT_EI_SUB:
        ei = _sub(SHAFT_EI_SUB[letter], size)
    else:
        raise ValueError("unsupported shaft letter: %s" % letter)
    return ei + it, ei


def _hole(letter, grade, size):
    """(ES, EI) in um for a hole."""
    i = _index(size)
    it = IT[grade][i]
    s = letter.lower()
    if s == "js":
        return it / 2.0, -it / 2.0
    if s in SHAFT_ES:
        ei_h = -SHAFT_ES[s][i]                   # EI = -es
        return ei_h + it, ei_h
    # J..ZC: ES = -ei, with the delta rule for K, M, N up to IT8 and P..ZC up to IT7
    if s == "k":
        ei = SHAFT_EI["k"][i] if grade <= 8 else 0
    elif s in SHAFT_EI:
        ei = SHAFT_EI[s][i]
    elif s in SHAFT_EI_SUB:
        ei = _sub(SHAFT_EI_SUB[s], size)
    else:
        raise ValueError("unsupported hole letter: %s" % letter)
    delta = IT[grade][i] - IT[grade - 1][i] if grade - 1 in IT else 0
    if s in ("k", "m", "n") and grade <= 8:
        es_h = -ei + delta
    elif s in ("p", "r", "s") and grade <= 7:
        es_h = -ei + delta
    elif s == "n" and grade > 8:
        es_h = 0
    elif s == "k" and grade > 8:
        es_h = 0
    else:
        es_h = -ei
    return es_h, es_h - it


def limits(size, cls):
    """Deviations (upper, lower) in mm for a tolerance class such as 'H7' or 'g6'."""
    m = re.match(r"^\s*([A-Za-z]{1,2})\s*(\d{1,2})\s*$", cls or "")
    if not m:
        raise ValueError("tolerance class format is letter + grade, for example H7 or g6")
    letter, grade = m.group(1), int(m.group(2))
    if grade not in IT or grade < 5:
        raise ValueError("supported grades: IT5 to IT11")
    if letter.isupper() or letter == "JS":
        up, lo = _hole(letter, grade, float(size))
    else:
        up, lo = _shaft(letter.lower(), grade, float(size))
    return up / 1000.0, lo / 1000.0


def fmt_dev(v):
    """Deviation text: 0, +0.021, -0.007."""
    if abs(v) < 1e-9:
        return "0"
    s = ("%.4f" % v).rstrip("0").rstrip(".")
    return ("+" + s) if v > 0 else s
