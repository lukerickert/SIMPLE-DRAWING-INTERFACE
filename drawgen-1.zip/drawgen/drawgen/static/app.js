"use strict";

window.addEventListener("error", (e) => {
  const st = document.getElementById("status-text");
  if (st) { st.textContent = "Script error: " + e.message + " (" + (e.filename || "").split("/").pop() + ":" + e.lineno + ")"; }
});
window.addEventListener("unhandledrejection", (e) => {
  const st = document.getElementById("status-text");
  const r = e.reason || {};
  if (st) { st.textContent = "Script error: " + (r.message || r) + " | " + ((r.stack || "").split("\n").slice(0, 3).join(" | ")); }
});

const $ = (s) => document.querySelector(s);
const state = { cfg: null, files: [], busy: 0 };
const VIEW_KEYS = ["orthographic", "section", "isometric", "hidden_lines", "smooth_lines"];
const AUTO_FIELDS = { Title: "auto: part name", DrawingNumber: "auto: from title", Date: "auto: today",
                      Scale: "auto", Mass: "auto with density" };
const FIELD_LABELS = {};

// ------------------------------------------------------------------ status

function busy(on, text) {
  state.busy += on ? 1 : -1;
  $("#spinner").hidden = state.busy <= 0;
  document.querySelectorAll("#btn-preview, #btn-export").forEach(b => b.disabled = state.busy > 0);
  if (text) status(text);
}
function showErr(e) {
  console.error(e);
  const where = (e && e.stack || "").split("\n").slice(1, 3).map(x => x.trim().replace(/https?:\/\/[^/]+\/static\//, "")).join(" | ");
  status((e && e.message || String(e)) + (where ? "  [" + where + "]" : ""), true);
}
function status(text, isError) {
  $("#status-text").textContent = text;
  $("#status").classList.toggle("error", !!isError);
}
async function api(url, opts) {
  const r = await fetch(url, opts);
  const ct = r.headers.get("content-type") || "";
  if (!r.ok) {
    const msg = ct.includes("json") ? (await r.json()).error : await r.text();
    throw new Error(msg || r.statusText);
  }
  return r;
}
function postJSON(url, body) {
  return api(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
}

// ------------------------------------------------------------------ config -> form

function scaleText(s) {
  return s >= 1 ? `${+s.toFixed(6)}:1` : `1:${+(1 / s).toFixed(6)}`;
}

function fillForm(cfg) {
  const sheet = $("#sheet");
  sheet.innerHTML = "";
  [...Object.keys(cfg.sheet_sizes_mm), "auto"].forEach(k => {
    const o = new Option(k === "auto" ? "Auto" : k, k);
    sheet.add(o);
  });
  sheet.value = cfg.sheet || "A3";
  const scale = $("#scale");
  scale.innerHTML = "";
  scale.add(new Option("Auto", "auto"));
  cfg.standard_scales.forEach(s => scale.add(new Option(scaleText(s), scaleText(s))));
  scale.value = cfg.scale || "auto";
  $("#mode").value = cfg.mode || "per_part";
  VIEW_KEYS.forEach(k => $("#v-" + k).checked = !!cfg.views[k]);
  $("#v-section_axis").value = cfg.views.section_axis || "X";
  $("#v-section_offset_mm").value = cfg.views.section_offset_mm || 0;
  $("#v-section_flip").checked = !!cfg.views.section_flip;
  $("#v-isometric_scale_factor").value = cfg.views.isometric_scale_factor ?? 1;
  $("#density").value = cfg.density_kg_per_m3 || 0;
  ["pdf", "dxf", "svg", "fcstd"].forEach(f => $("#f-" + f).checked = (cfg.outputs || []).includes(f));
  $("#out-dir").value = cfg.output_dir || "";

  cfg.title_block.cells.forEach(c => FIELD_LABELS[c.key] = c.label);
  const box = $("#fields");
  box.innerHTML = "";
  Object.entries(cfg.fields).forEach(([k, v]) => {
    const lab = document.createElement("label");
    lab.textContent = FIELD_LABELS[k] || k;
    const inp = document.createElement("input");
    inp.type = "text";
    inp.dataset.key = k;
    inp.value = v;
    if (AUTO_FIELDS[k]) inp.placeholder = AUTO_FIELDS[k];
    if (k === "Scale") { inp.disabled = true; inp.value = ""; }
    lab.appendChild(inp);
    box.appendChild(lab);
  });
  fillEditor(cfg);
}

function readSettings() {
  const views = {};
  VIEW_KEYS.forEach(k => views[k] = $("#v-" + k).checked);
  views.section_axis = $("#v-section_axis").value;
  views.section_offset_mm = parseFloat($("#v-section_offset_mm").value) || 0;
  views.section_flip = $("#v-section_flip").checked;
  views.isometric_scale_factor = parseFloat($("#v-isometric_scale_factor").value) || 1;
  return { sheet: $("#sheet").value, scale: $("#scale").value, mode: $("#mode").value, views,
           density_kg_per_m3: parseFloat($("#density").value) || 0 };
}
function readFields() {
  const f = {};
  document.querySelectorAll("#fields input").forEach(i => { if (i.dataset.key !== "Scale") f[i.dataset.key] = i.value; });
  return f;
}
function readFormats() {
  return ["pdf", "dxf", "svg", "fcstd"].filter(f => $("#f-" + f).checked);
}
function selection() {
  return state.files.map(f => ({
    file_id: f.file_id,
    part_ids: f.parts.filter(p => p.checked).map(p => p.id),
  })).filter(s => s.part_ids.length);
}

// ------------------------------------------------------------------ files

function renderFiles() {
  const box = $("#files");
  box.innerHTML = "";
  state.files.forEach(f => {
    const el = document.createElement("div");
    el.className = "file";
    const head = document.createElement("div");
    head.className = "file-head";
    const name = document.createElement("strong");
    name.textContent = f.name;
    name.title = f.source || f.name;
    const rm = document.createElement("button");
    rm.type = "button";
    rm.textContent = "×";
    rm.title = "Remove";
    rm.onclick = async () => {
      await api("/api/files/" + f.file_id, { method: "DELETE" });
      state.files = state.files.filter(x => x !== f);
      renderFiles();
    };
    head.append(name, rm);
    el.appendChild(head);
    f.parts.forEach(p => {
      const row = document.createElement("label");
      row.className = "part check";
      const cb = document.createElement("input");
      cb.type = "checkbox";
      cb.checked = p.checked;
      cb.onchange = () => p.checked = cb.checked;
      const t = document.createElement("span");
      t.textContent = p.name;
      const dim = document.createElement("span");
      dim.className = "dim";
      dim.textContent = p.size_mm.map(v => +v.toFixed(1)).join(" x ") + " mm";
      row.append(cb, t, dim);
      el.appendChild(row);
    });
    box.appendChild(el);
  });
}

function addFiles(res) {
  res.files.forEach(f => { f.parts.forEach(p => p.checked = true); state.files.push(f); });
  renderFiles();
  const n = res.files.reduce((a, f) => a + f.parts.length, 0);
  if (res.errors && res.errors.length) status(res.errors.join("; "), true);
  else status(`Loaded ${res.files.length} file(s), ${n} part(s)`);
}

async function uploadFiles(list) {
  const files = [...list].filter(f => /\.(step|stp)$/i.test(f.name));
  if (!files.length) return status("No STEP files selected", true);
  const fd = new FormData();
  files.forEach(f => fd.append("files", f));
  busy(true, `Reading ${files.length} file(s)...`);
  try {
    const r = await api("/api/upload", { method: "POST", body: fd });
    addFiles(await r.json());
  } catch (e) { showErr(e); }
  finally { busy(false); }
}

async function openPath() {
  const path = $("#path-input").value.trim();
  if (!path) return;
  busy(true, "Reading " + path + " ...");
  try {
    const r = await postJSON("/api/open_path", { path });
    addFiles(await r.json());
  } catch (e) { showErr(e); }
  finally { busy(false); }
}

// ------------------------------------------------------------------ preview / export

function request() {
  return { selection: selection(), settings: readSettings(), fields: readFields() };
}

async function preview() {
  const req = request();
  if (!req.selection.length) return status("No parts selected", true);
  busy(true, "Projecting views...");
  const t0 = performance.now();
  try {
    const r = await postJSON("/api/preview", req);
    const data = await r.json();
    state.drawings = data.drawings;
    const box = $("#previews");
    box.innerHTML = "";
    data.drawings.forEach(d => {
      const card = document.createElement("div");
      card.className = "card";
      card.innerHTML = `<div class="card-head"><strong></strong><span>${d.sheet}</span><span>${d.scale}</span>` +
                       `<button type="button" class="quiet small">Dimensions and notes</button></div>` +
                       `<div class="sheet">${d.svg}</div>`;
      card.querySelector("strong").textContent = d.name;
      card.querySelector("button").onclick = () => openAnnotator(d.name);
      box.appendChild(card);
    });
    showTab("drawings");
    status(`${data.drawings.length} drawing(s) in ${((performance.now() - t0) / 1000).toFixed(1)} s`);
    try {
      if (window.annotatorDrawingsChanged) annotatorDrawingsChanged();
    } catch (e) {
      console.error(e);
      status("Dimensions editor: " + e.message + " | " + (e.stack || "").split("\n").slice(0, 3).join(" | "), true);
    }
  } catch (e) { console.error(e); status(e.message + " | " + (e.stack || "").split("\n").slice(0, 3).join(" | "), true); }
  finally { busy(false); }
}

async function exportFiles() {
  const req = request();
  if (!req.selection.length) return status("No parts selected", true);
  req.formats = readFormats();
  if (!req.formats.length) return status("No output format selected", true);
  req.out_dir = $("#out-dir").value.trim();
  req.next_to_source = $("#next-to-source").checked;
  busy(true, "Exporting...");
  try {
    const r = await postJSON("/api/export", req);
    const ct = r.headers.get("content-type") || "";
    if (ct.includes("json")) {
      const data = await r.json();
      status(`Wrote ${data.written.length} file(s): ${data.written.join(", ")}`);
    } else {
      const blob = await r.blob();
      const cd = r.headers.get("content-disposition") || "";
      const m = /filename\*?=(?:UTF-8'')?"?([^";]+)"?/i.exec(cd);
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = m ? decodeURIComponent(m[1]) : "drawings.zip";
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 2000);
      status("Downloaded " + a.download);
    }
  } catch (e) { showErr(e); }
  finally { busy(false); }
}

async function saveDefaults() {
  const cfg = structuredClone(state.cfg);
  const st = readSettings();
  cfg.sheet = st.sheet; cfg.scale = st.scale; cfg.mode = st.mode;
  Object.assign(cfg.views, st.views);
  cfg.density_kg_per_m3 = st.density_kg_per_m3;
  cfg.outputs = readFormats();
  cfg.output_dir = $("#out-dir").value.trim();
  const f = readFields();
  ["Title", "SupplementaryTitle", "DrawingNumber", "Date", "Mass", "Material"].forEach(k => { if (k in f) f[k] = ""; });
  Object.assign(cfg.fields, f);
  try {
    await postJSON("/api/config", cfg);
    state.cfg = cfg;
    status("Defaults saved");
  } catch (e) { showErr(e); }
}

// ------------------------------------------------------------------ title block editor

function fillEditor(cfg) {
  const tb = cfg.title_block;
  ["width_mm", "height_mm", "label_size_mm", "font"].forEach(k => $("#tb-" + k).value = tb[k]);
  $("#tb-logo_cell").value = tb.logo_cell.join(", ");
  $("#tb-projection_cell").value = tb.projection_cell.join(", ");
  $("#b-left_mm").value = cfg.border.left_mm;
  $("#b-other_mm").value = cfg.border.other_mm;
  $("#logo-name").textContent = tb.logo_file || "No logo";
  const body = $("#cells tbody");
  body.innerHTML = "";
  tb.cells.forEach(c => addCellRow(c));
  tbPreview();
}

function addCellRow(c) {
  c = c || { key: "NewField", label: "New field", x: 0, y: 0, w: 20, h: 8, size: 2.5 };
  const tr = document.createElement("tr");
  const cols = [["key", "text"], ["label", "text"], ["x", "number"], ["y", "number"], ["w", "number"], ["h", "number"], ["size", "number"]];
  cols.forEach(([k, type]) => {
    const td = document.createElement("td");
    if (type === "number") td.className = "num";
    const inp = document.createElement("input");
    inp.type = type;
    inp.step = "any";
    inp.dataset.k = k;
    inp.value = c[k];
    td.appendChild(inp);
    tr.appendChild(td);
  });
  const td = document.createElement("td");
  const del = document.createElement("button");
  del.type = "button";
  del.textContent = "×";
  del.onclick = () => tr.remove();
  td.appendChild(del);
  tr.appendChild(td);
  $("#cells tbody").appendChild(tr);
}

function nums(s) {
  const v = s.split(/[ ,;]+/).filter(Boolean).map(Number);
  if (v.length !== 4 || v.some(isNaN)) throw new Error("cell must be four numbers: " + s);
  return v;
}

function readEditor() {
  const cfg = structuredClone(state.cfg);
  const tb = cfg.title_block;
  tb.width_mm = parseFloat($("#tb-width_mm").value);
  tb.height_mm = parseFloat($("#tb-height_mm").value);
  tb.label_size_mm = parseFloat($("#tb-label_size_mm").value);
  tb.font = $("#tb-font").value;
  tb.logo_cell = nums($("#tb-logo_cell").value);
  tb.projection_cell = nums($("#tb-projection_cell").value);
  cfg.border.left_mm = parseFloat($("#b-left_mm").value);
  cfg.border.other_mm = parseFloat($("#b-other_mm").value);
  tb.cells = [...document.querySelectorAll("#cells tbody tr")].map(tr => {
    const c = {};
    tr.querySelectorAll("input").forEach(i => c[i.dataset.k] = i.type === "number" ? parseFloat(i.value) : i.value.trim());
    return c;
  }).filter(c => c.key);
  tb.cells.forEach(c => { if (!(c.key in cfg.fields)) cfg.fields[c.key] = ""; });
  return cfg;
}

async function tbPreview() {
  let cfg;
  try { cfg = readEditor(); } catch (e) { return showErr(e); }
  cfg._preview_sheet = $("#sheet").value === "auto" ? "A3" : $("#sheet").value;
  try {
    const r = await postJSON("/api/titleblock_preview", cfg);
    const svg = (await r.json()).svg;
    $("#tb-sheet").innerHTML = svg;
    $("#tb-zoom").innerHTML = svg;
    const [W, H] = cfg.sheet_sizes_mm[cfg._preview_sheet];
    const tb = cfg.title_block, other = cfg.border.other_mm;
    const x = W - other - tb.width_mm - 3, y = H - other - tb.height_mm - 3;
    const z = $("#tb-zoom svg");
    z.setAttribute("viewBox", `${x} ${y} ${tb.width_mm + 6} ${tb.height_mm + 6}`);
    z.removeAttribute("width"); z.removeAttribute("height");
    $("#tb-sheet svg").removeAttribute("width"); $("#tb-sheet svg").removeAttribute("height");
  } catch (e) { showErr(e); }
}

async function tbSave() {
  let cfg;
  try { cfg = readEditor(); } catch (e) { return showErr(e); }
  try {
    await postJSON("/api/config", cfg);
    state.cfg = cfg;
    const vals = readFields();
    fillForm(cfg);
    document.querySelectorAll("#fields input").forEach(i => { if (i.dataset.key in vals && i.dataset.key !== "Scale") i.value = vals[i.dataset.key]; });
    status("Title block saved");
  } catch (e) { showErr(e); }
}

async function uploadLogo(file) {
  const fd = new FormData();
  fd.append("file", file);
  try {
    const r = await api("/api/logo", { method: "POST", body: fd });
    state.cfg.title_block.logo_file = (await r.json()).logo_file;
    $("#logo-name").textContent = state.cfg.title_block.logo_file + " (save the title block to keep it)";
    tbPreview();
  } catch (e) { showErr(e); }
}

// ------------------------------------------------------------------ tabs and events

function showTab(name) {
  document.querySelectorAll(".tab").forEach(t => t.classList.toggle("active", t.dataset.tab === name));
  $("#tab-drawings").hidden = name !== "drawings";
  $("#tab-annotate").hidden = name !== "annotate";
  $("#tab-editor").hidden = name !== "editor";
  if (name === "annotate" && window.annotatorShown) annotatorShown();
}

function bind() {
  document.querySelectorAll(".tab").forEach(t => t.onclick = () => showTab(t.dataset.tab));
  $("#file-input").onchange = (e) => { uploadFiles(e.target.files); e.target.value = ""; };
  const drop = $("#drop");
  ["dragenter", "dragover"].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add("over"); }));
  ["dragleave", "drop"].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove("over"); }));
  drop.addEventListener("drop", e => uploadFiles(e.dataTransfer.files));
  $("#path-open").onclick = openPath;
  $("#path-input").addEventListener("keydown", e => { if (e.key === "Enter") openPath(); });
  $("#btn-preview").onclick = preview;
  $("#btn-export").onclick = exportFiles;
  $("#btn-save").onclick = saveDefaults;
  $("#cell-add").onclick = () => addCellRow();
  $("#tb-preview").onclick = tbPreview;
  $("#tb-save").onclick = tbSave;
  $("#logo-input").onchange = (e) => { if (e.target.files[0]) uploadLogo(e.target.files[0]); e.target.value = ""; };
  $("#logo-clear").onclick = () => { state.cfg.title_block.logo_file = ""; $("#logo-name").textContent = "No logo (save the title block to keep it)"; tbPreview(); };
}

(async function init() {
  bind();
  try {
    const r = await api("/api/config");
    state.cfg = await r.json();
    fillForm(state.cfg);
  } catch (e) { status("Could not load configuration: " + e.message, true); }
})();
