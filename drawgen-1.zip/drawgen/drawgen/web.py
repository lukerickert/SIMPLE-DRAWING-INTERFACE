# -*- coding: utf-8 -*-
"""Local web server for the drawing generator."""
import io
import json
import os
import re
import shutil
import tempfile
import threading
import traceback
import uuid
import zipfile

from flask import Flask, jsonify, request, send_file, send_from_directory

from . import drawing, fcstd, fits, model, render
from . import titleblock as tbk

APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_PATH = os.path.join(APP_DIR, "config.json")
STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
WORK_DIR = tempfile.mkdtemp(prefix="drawgen_")
STEP_EXT = (".step", ".stp")
ANN_DIR = os.path.join(APP_DIR, "annotations")

app = Flask(__name__, static_folder=None)
app.json.sort_keys = False
FILES = {}          # file id -> {"name", "path", "source", "parts": [Part]}
CACHE = {}          # projection cache
LOCK = threading.Lock()


# --------------------------------------------------------------------------- helpers

def load_config():
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def save_config(cfg):
    tmp = CONFIG_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)
    os.replace(tmp, CONFIG_PATH)


def safe_name(s):
    return re.sub(r"[^A-Za-z0-9_\-.]+", "_", s).strip("_") or "drawing"


def error(msg, code=400):
    return jsonify({"error": msg}), code


def _register(path, source=None):
    parts = model.load_step(path)
    fid = uuid.uuid4().hex[:10]
    name = os.path.basename(source or path)
    with LOCK:
        FILES[fid] = {"name": name, "path": path, "source": source, "parts": parts}
    return {"file_id": fid, "name": name, "source": source or "",
            "parts": [p.info() for p in parts]}


def effective_config(req):
    """Saved configuration with the request's sheet, scale, view and field settings applied."""
    cfg = load_config()
    st = req.get("settings") or {}
    for k in ("sheet", "scale", "mode"):
        if st.get(k):
            cfg[k] = st[k]
    for k, v in (st.get("views") or {}).items():
        cfg["views"][k] = v
    if "density_kg_per_m3" in st:
        cfg["density_kg_per_m3"] = float(st["density_kg_per_m3"] or 0)
    return cfg


def build_drawings(req):
    """Compose drawings for the request. Returns list of drawing dicts and the config used."""
    cfg = effective_config(req)
    fields = req.get("fields") or {}
    mode = cfg.get("mode", "per_part")
    out = []
    for sel in req.get("selection") or []:
        f = FILES.get(sel.get("file_id"))
        if f is None:
            continue
        ids = set(sel.get("part_ids") or [p.id for p in f["parts"]])
        parts = [p for p in f["parts"] if p.id in ids]
        if not parts:
            continue
        stem = os.path.splitext(f["name"])[0]
        if mode == "per_part":
            groups = [(("%s_%s" % (stem, p.name)) if len(f["parts"]) > 1 else stem, p.name, [p]) for p in parts]
        else:
            groups = [(stem, stem, parts)]
        for fname, title, group in groups:
            shape = model.compound([p.shape for p in group])
            vol = sum(p.volume for p in group)
            key = (sel["file_id"], tuple(p.id for p in group))
            fname = safe_name(fname)
            d = drawing.compose(title, shape, vol, cfg, cfg.get("sheet", "A3"),
                                drawing.parse_scale(cfg.get("scale", "auto")), fields,
                                cache=CACHE, key=key, base_dir=APP_DIR,
                                annotations=load_annotations(fname),
                                view_offsets=load_layout(fname).get("offsets"))
            d["selection"] = {"file_id": sel["file_id"], "part_ids": [p.id for p in group]}
            d["file_name"] = fname
            d["shape"] = shape
            d["part_label"] = title
            d["source"] = f.get("source")
            out.append(d)
    return out, cfg


def _ann_path(name):
    return os.path.join(ANN_DIR, safe_name(name) + ".json")


def _layout_path(name):
    return os.path.join(ANN_DIR, safe_name(name) + ".layout.json")


def load_layout(name):
    try:
        with open(_layout_path(name), "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def load_annotations(name):
    try:
        with open(_ann_path(name), "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return []


# --------------------------------------------------------------------------- routes

@app.route("/api/annotations/<name>", methods=["GET"])
def get_annotations(name):
    return jsonify(load_annotations(name))


@app.route("/api/annotations/<name>", methods=["PUT"])
def put_annotations(name):
    anns = request.get_json(force=True)
    if not isinstance(anns, list):
        return error("annotation list expected")
    os.makedirs(ANN_DIR, exist_ok=True)
    tmp = _ann_path(name) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(anns, f, indent=1)
    os.replace(tmp, _ann_path(name))
    return jsonify({"ok": True, "count": len(anns)})


@app.route("/api/layout/<name>", methods=["PUT"])
def put_layout(name):
    lay = request.get_json(force=True)
    if not isinstance(lay, dict):
        return error("layout object expected")
    os.makedirs(ANN_DIR, exist_ok=True)
    tmp = _layout_path(name) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(lay, f, indent=1)
    os.replace(tmp, _layout_path(name))
    return jsonify({"ok": True})


@app.route("/api/fits", methods=["GET"])
def fit_classes():
    return jsonify({"holes": fits.HOLE_CLASSES, "shafts": fits.SHAFT_CLASSES})


@app.route("/api/fit", methods=["POST"])
def fit_limits():
    req = request.get_json(force=True)
    try:
        up, lo = fits.limits(float(req["size"]), req["cls"])
    except (KeyError, ValueError) as e:
        return error(str(e))
    return jsonify({"upper": up, "lower": lo, "upper_text": fits.fmt_dev(up), "lower_text": fits.fmt_dev(lo)})


@app.route("/")
def index():
    return send_from_directory(STATIC_DIR, "index.html")


@app.route("/static/<path:p>")
def static_files(p):
    return send_from_directory(STATIC_DIR, p, max_age=0)


@app.after_request
def no_cache(resp):
    resp.headers["Cache-Control"] = "no-store"
    return resp


@app.route("/api/config", methods=["GET"])
def get_config():
    return jsonify(load_config())


@app.route("/api/config", methods=["POST"])
def post_config():
    cfg = request.get_json(force=True)
    try:
        for key in ("sheet_sizes_mm", "title_block", "fields", "views", "border"):
            if key not in cfg:
                return error("missing key: %s" % key)
        save_config(cfg)
    except Exception as e:
        return error(str(e))
    return jsonify({"ok": True})


@app.route("/api/upload", methods=["POST"])
def upload():
    res, errs = [], []
    for fs in request.files.getlist("files"):
        name = os.path.basename(fs.filename or "upload.step")
        if not name.lower().endswith(STEP_EXT):
            errs.append("%s: not a STEP file" % name)
            continue
        d = os.path.join(WORK_DIR, uuid.uuid4().hex[:8])
        os.makedirs(d)
        path = os.path.join(d, name)
        fs.save(path)
        try:
            res.append(_register(path))
        except Exception as e:
            errs.append("%s: %s" % (name, e))
    return jsonify({"files": res, "errors": errs})


@app.route("/api/open_path", methods=["POST"])
def open_path():
    p = (request.get_json(force=True).get("path") or "").strip().strip('"')
    if not p or not os.path.exists(p):
        return error("path not found: %s" % p)
    paths = []
    if os.path.isdir(p):
        paths = [os.path.join(p, n) for n in sorted(os.listdir(p)) if n.lower().endswith(STEP_EXT)]
    elif p.lower().endswith(STEP_EXT):
        paths = [p]
    if not paths:
        return error("no STEP files in %s" % p)
    res, errs = [], []
    for path in paths:
        try:
            res.append(_register(path, source=path))
        except Exception as e:
            errs.append("%s: %s" % (os.path.basename(path), e))
    return jsonify({"files": res, "errors": errs})


@app.route("/api/files/<fid>", methods=["DELETE"])
def remove_file(fid):
    with LOCK:
        FILES.pop(fid, None)
        for k in [k for k in CACHE if k[0] and k[0][0] == fid]:
            CACHE.pop(k, None)
    return jsonify({"ok": True})


@app.route("/api/preview", methods=["POST"])
def preview():
    req = request.get_json(force=True)
    try:
        ds, cfg = build_drawings(req)
    except Exception as e:
        traceback.print_exc()
        return error("preview failed: %s" % e, 500)
    return jsonify({"drawings": [{"name": d["file_name"], "sheet": d["sheet"],
                                  "scale": drawing.scale_text(d["scale"]),
                                  "size": d["size"], "selection": d["selection"],
                                  "maps": d["meta"]["maps"], "snaps": drawing.snaps(d["views"]),
                                  "annotations": load_annotations(d["file_name"]),
                                  "layout": load_layout(d["file_name"]),
                                  "svg": render.to_svg(d, cfg)} for d in ds]})


@app.route("/api/export", methods=["POST"])
def export():
    req = request.get_json(force=True)
    formats = [f for f in (req.get("formats") or ["pdf", "dxf"]) if f in ("pdf", "dxf", "svg", "fcstd")]
    out_dir = (req.get("out_dir") or "").strip().strip('"')
    try:
        ds, cfg = build_drawings(req)
    except Exception as e:
        traceback.print_exc()
        return error("export failed: %s" % e, 500)
    if not ds:
        return error("nothing selected")
    files = []
    for d in ds:
        if "pdf" in formats:
            files.append((d, d["file_name"] + ".pdf", render.to_pdf([d], cfg)))
        if "dxf" in formats:
            files.append((d, d["file_name"] + ".dxf", render.to_dxf(d, cfg)))
        if "svg" in formats:
            files.append((d, d["file_name"] + ".svg", render.to_svg(d, cfg).encode("utf-8")))
        if "fcstd" in formats:
            files.append((d, d["file_name"] + ".FCStd", fcstd.build(d, cfg, d["shape"], d["part_label"])))
    if out_dir or req.get("next_to_source"):
        written = []
        for d, name, data in files:
            target = out_dir
            if not target and d.get("source"):
                target = os.path.join(os.path.dirname(d["source"]), "drawings")
            if not target:
                return error("no output folder for uploaded files")
            os.makedirs(target, exist_ok=True)
            path = os.path.join(target, name)
            with open(path, "wb") as f:
                f.write(data)
            written.append(path)
        return jsonify({"written": written})
    if len(files) == 1:
        _, name, data = files[0]
        return send_file(io.BytesIO(data), as_attachment=True, download_name=name)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for _, name, data in files:
            z.writestr(name, data)
    buf.seek(0)
    return send_file(buf, as_attachment=True, download_name="drawings.zip", mimetype="application/zip")


@app.route("/api/titleblock_preview", methods=["POST"])
def titleblock_preview():
    cfg = request.get_json(force=True)
    sheet = cfg.get("_preview_sheet") or cfg.get("sheet", "A3")
    if str(sheet).lower() == "auto":
        sheet = "A3"
    try:
        vals = dict(cfg["fields"])
        for k in ("Title", "DrawingNumber", "Date", "Scale"):
            vals[k] = vals.get(k) or {"Title": "Part name", "DrawingNumber": "PART_NAME",
                                      "Date": "2026-01-01", "Scale": "1:1"}[k]
        W, H = tbk.sheet_size(cfg, sheet)
        d = {"size": (W, H), "prims": tbk.sheet_primitives(cfg, sheet, vals, True, APP_DIR)}
        return jsonify({"svg": render.to_svg(d, cfg)})
    except Exception as e:
        return error(str(e))


@app.route("/api/logo", methods=["POST"])
def logo():
    fs = request.files.get("file")
    if fs is None:
        return error("no file")
    ext = os.path.splitext(fs.filename or "")[1].lower()
    if ext not in (".png", ".jpg", ".jpeg"):
        return error("logo must be PNG or JPG")
    name = "logo" + ext
    fs.save(os.path.join(APP_DIR, name))
    return jsonify({"logo_file": name})


def cleanup():
    shutil.rmtree(WORK_DIR, ignore_errors=True)
