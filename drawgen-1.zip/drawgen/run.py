# -*- coding: utf-8 -*-
"""Starts the drawing generator at http://localhost:<port> and opens the browser."""
import argparse
import atexit
import json
import multiprocessing
import os
import threading
import webbrowser


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(here, "config.json"), "r", encoding="utf-8") as f:
        port = int(json.load(f).get("port", 8765))
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=port)
    ap.add_argument("--no-browser", action="store_true")
    a = ap.parse_args()

    import socket
    probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        probe.bind(("127.0.0.1", a.port))
    except OSError:
        print("Port %d is already in use, probably by an earlier Drawing Generator window." % a.port)
        print("Close that window (or end python.exe in Task Manager) and start again.")
        return 1
    finally:
        probe.close()

    from drawgen import web
    atexit.register(web.cleanup)
    url = "http://localhost:%d" % a.port
    print("Drawing generator running at %s (Ctrl+C to stop)" % url)
    if not a.no_browser:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    web.app.run(host="127.0.0.1", port=a.port, threaded=True, debug=False, use_reloader=False)


if __name__ == "__main__":
    multiprocessing.freeze_support()
    raise SystemExit(main())
