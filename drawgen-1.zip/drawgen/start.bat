@echo off
rem Drawing Generator: creates the Python environment on first start, then starts the server.
rem The environment is placed in %LOCALAPPDATA%\drawgen\venv to keep file paths below the
rem Windows 260 character limit.
cd /d "%~dp0"
set VENV=%LOCALAPPDATA%\drawgen\venv
if exist "%VENV%\Scripts\python.exe" if exist "%VENV%\installed.txt" goto run

echo Creating Python environment in %VENV%
set PY=
for %%v in (3.14 3.13 3.12 3.11 3.10) do (
  if not defined PY (
    py -%%v -c "import sys" >nul 2>&1 && set PY=py -%%v
  )
)
if not defined PY (
  echo Python 3.10 to 3.14 not found by the py launcher. Installed versions:
  py -0
  pause
  exit /b 1
)
echo Using %PY%
if exist "%VENV%" rmdir /s /q "%VENV%"
%PY% -m venv "%VENV%"
if errorlevel 1 (
  echo Creating the environment failed.
  pause
  exit /b 1
)
"%VENV%\Scripts\python.exe" -m pip install --upgrade pip
"%VENV%\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
  echo Package installation failed.
  pause
  exit /b 1
)
echo ok> "%VENV%\installed.txt"

:run
"%VENV%\Scripts\python.exe" run.py %*
pause
